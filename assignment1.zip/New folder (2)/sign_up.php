<?php
$host="localhost"; 
$username="root"; 
$password=""; 
$db_name="healthstore"; 
$tbl_name="signup"; 
$con = mysqli_connect("$host", "$username", "$password", $db_name);
if (!$con)
{
die("cannot connect");
}
$fname=$_REQUEST['fname'];
$lname=$_REQUEST['lname'];
$uname=$_REQUEST['uname'];
$password=$_REQUEST['password'];
$confirmpassword=$_REQUEST['confirmpassword'];
$email=$_REQUEST['email'];
$sql="INSERT INTO signup(uname,password,fname,lname,email,confirmpassword)VALUES('$uname','$password','$fname','$lname','$email','$confirmpassword')";
$result=mysqli_query($con,$sql);
if($result){
echo "Successful";
echo "<BR>";
echo "<a href='sign_up.html'>Back to main page</a>";
}
else {
echo "ERROR";
}
?>