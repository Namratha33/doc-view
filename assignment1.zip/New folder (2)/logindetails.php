<?php
echo "Creation of login table under healthstore db <br>";
echo "----------------------------------------------<br>";
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "healthstore";
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
 die("Connection failed: " . mysqli_connect_error());
}
$sql = "CREATE TABLE login(username  VARCHAR(9) NOT NULL,password VARCHAR(9))";

if (mysqli_query($conn, $sql)) {
 echo "Table course created successfully";
} else {
 echo "Error creating table: " . mysqli_error($conn);
}
?>